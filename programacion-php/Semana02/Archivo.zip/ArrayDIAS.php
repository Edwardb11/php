<?php

$dias = array(
    array('dia_id' => '0','dia' => 'Domingo'),
    array('dia_id' => '1','dia' => 'Lunes'),
    array('dia_id' => '2','dia' => 'Martes'),
    array('dia_id' => '3','dia' => 'Miercoles'),
    array('dia_id' => '4','dia' => 'Jueves'),
    array('dia_id' => '5','dia' => 'Viernes'),
    array('dia_id' => '6','dia' => 'Sabado'),

);

